﻿// © 2010 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System.Windows.Forms;


public partial class HostForm : Form
{
   public HostForm()
   {
      InitializeComponent();
   }
}
