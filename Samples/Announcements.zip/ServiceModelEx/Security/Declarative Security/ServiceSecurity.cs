﻿// © 2010 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace ServiceModelEx
{
   public enum ServiceSecurity
   {
      None,
      Anonymous,
      BusinessToBusiness,
      Internet,
      Intranet,
      ServiceBus
   }
}