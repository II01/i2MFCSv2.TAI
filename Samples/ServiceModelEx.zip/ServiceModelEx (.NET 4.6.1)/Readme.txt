There are 4 flavors of ServiceModelEx for .NET 4.6.1:

1) Essentials   - compatible with the 4th edition of Programming WCF Services, for developers who do not use the Azure Service Fabric

2) Service Fabric - compatible with the 4th edition of Programming WCF Services, but for developers who also target the Azure Service Fabric

3) Service Bus � same as essentials but with the Azure Service Bus code presented with the 3rd edition of Programming WCF Services

4) Full � contains Essentials, the Service Fabric and the Service Bus
