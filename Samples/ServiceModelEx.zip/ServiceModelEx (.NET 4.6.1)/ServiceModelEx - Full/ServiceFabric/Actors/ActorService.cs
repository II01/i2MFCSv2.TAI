﻿using System;
using ServiceModelEx.ServiceFabric.Services.Remoting;

namespace ServiceModelEx.ServiceFabric.Actors
{
   [Serializable]
   public class ActorService : IService
   {}
}
