﻿using ServiceModelEx.ServiceFabric.Services.Communication.Runtime;

namespace ServiceModelEx.ServiceFabric.Services.Remoting.Runtime
{
   public interface IServiceRemotingListener : ICommunicationListener
   {}
}
