﻿// © 2016 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace ServiceModelEx.ServiceFabric.Services.Communication.Client
{
   public interface ICommunicationClient
   {}
}
