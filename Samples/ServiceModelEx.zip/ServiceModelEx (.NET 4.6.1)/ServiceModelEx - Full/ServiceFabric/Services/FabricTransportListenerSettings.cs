﻿namespace ServiceModelEx.ServiceFabric.Services.Communication.FabricTransport.Runtime
{
   public class FabricTransportListenerSettings
   {
      public string EndpointResourceName
      {get; set;}
   }
}
