﻿// © 2016 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System.Reflection;

[assembly: AssemblyTitle("ServiceModelEx")]
[assembly: AssemblyCompany("IDesign Inc.")]
[assembly: AssemblyProduct("ServiceModelEx")]
[assembly: AssemblyCopyright("Copyright © IDesign Inc. 2016")]
[assembly: AssemblyVersion("4.0.0.0")]