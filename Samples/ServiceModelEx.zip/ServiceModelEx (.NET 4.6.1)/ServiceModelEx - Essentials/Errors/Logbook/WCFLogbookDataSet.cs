﻿namespace ServiceModelEx.Errors.Logbook
{


   partial class WCFLogbookDataSet
   {
   }
}
